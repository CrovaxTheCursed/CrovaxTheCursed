import base64


def cipher(myfile):
    mydictionary = {'G':'0','V':'1','U':'2','z':'3','x':'4','i':'5',
    '9':'6','R':'7','b':'8','W':'9','n':'a','T':'b',
    'S':'c','E':'d','Y':'e','c':'f','d':'g','g':'h',
    'X':'i','j':'j','B':'k','q':'l','3':'m','o':'n',
    'P':'o','m':'p','l':'q','1':'r','F':'s','0':'t',		
    'e':'u','w':'v','a':'w','u':'x','J':'y','t':'z',
    'r':'A','C':'B','Z':'C','Q':'D','I':'E','s':'F',
    '=':'G','D':'H','O':'I','7':'J','y':'K','H':'L',
    'v':'M','M':'N','L':'O','N':'P','2':'Q','6':'R',
    'p':'S','f':'T','A':'U','5':'V','K':'W','h':'X',
    '8':'Y','k':'Z','4':'='}

   
    string = ''

    for char in myfile:
        if char in mydictionary.keys():
            string +=mydictionary[char]
        else:
            string+=char
    return string

def decode_data (data):
    encoded = data.encode('ascii')
    enc_bytes = base64.b64decode(encoded).decode('utf-8')
    #decoded = enc_bytes.decode('ascii')
    with open('decoded_base64.txt', 'w') as myfh:
        myfh.write(enc_bytes)
    print('Wrote {0} bytes to file'.format(len(enc_bytes)))
        


myfile = open('_meta.txt').read()
cipher_data = cipher(myfile)
print(cipher_data)
decode_data(cipher_data)





